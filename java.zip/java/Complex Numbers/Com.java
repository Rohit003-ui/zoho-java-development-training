import java.util.*;

class C{ 
int a;
int b;
char i;
 
 C(int a,int b,char i){
   this.a=a;
   this.b=b;
   this.i=i;
 }
 void add(C num){
    System.out.println((this.a+=num.a)+"+"+(this.b+=num.b)+this.i);
 }


}

public class Com{
public static void main(String[] args){

Scanner sc=new Scanner(System.in);
System.out.println("Enter the Value for A: ");
int a1=sc.nextInt();
System.out.println("Enter the Value for i: ");
char i1=sc.next().charAt(0);
System.out.println("Enter the Value for B: ");
int b1=sc.nextInt();

System.out.println("Enter the Value for A: ");
int a2=sc.nextInt();
System.out.println("Enter the Value for i: ");
char i2=sc.next().charAt(0);
System.out.println("Enter the Value for B: ");
int b2=sc.nextInt();

C c1=new C(a1,b1,i1);
C c2=new C(a2,b2,i2);
c1.add(c2);

}

}

