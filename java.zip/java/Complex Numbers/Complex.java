import java.util.*;

class Complex{

void add(int r1,int i1,int r2,int i2){
  System.out.println("Addition of Real and Imaginary is : "+(r1+r2)+" + " + ""+(i1+i2)+"i");
}

void sub(int r1,int i1,int r2,int i2){
  System.out.println("Subtraction of Real and Imaginary is : "+(r1-r2)+" - " + ""+(i1-i2)+"i");
}

void mul(int r1,int i1,int r2,int i2){
  System.out.println("Multiplication of Real and Imaginary is : "+(r1*r2)+" + " + ""+(i1*i2)+"i");
}

void div(int r1,int i1,int r2,int i2){
  System.out.println("Division of Real and Imaginary is : "+(r1/r2)+" + " + ""+(i1/i2)+"i");
}

public static void main(String[] args){
Scanner sc=new Scanner(System.in);
 Complex c=new Complex();

  System.out.println("Enter the Real Number 1 : ");
  int real=sc.nextInt();
  System.out.println("Enter the Imaginary Number 1 : ");
  int imaginary=sc.nextInt();
  System.out.println("Enter the Real Number 2 : ");
  int re=sc.nextInt();
  System.out.println("Enter the Imaginary Number 2 : ");
  int img=sc.nextInt();

 System.out.println("\n1. Addition \n2. Subtraction \n3. Multiplication \n4. Division");
 System.out.println("\nEnter the Operation You need to do :");
 int sel=sc.nextInt();

 switch(sel){
   case 1:
     c.add(real,imaginary,re,img);
     break;
   case 2:
     c.sub(real,imaginary,re,img);
     break;
   case 3:
     c.mul(real,imaginary,re,img);
     break;
   case 4:
     c.div(real,imaginary,re,img);
     break;
 }

 


}
}