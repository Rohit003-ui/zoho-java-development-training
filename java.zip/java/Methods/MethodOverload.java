import java.util.*;

class MethodOverload{

 void number(int[] arr){
   for(int i=0;i<arr.length;i++)
     System.out.println(arr[i]);
 }

 void number(int[] arr){
  for(int i=0;i<arr.length;i++)
     System.out.println(arr[i]);
 } 

public static void main(String[] args){

int[] num={1,2,3,4,5,6,7,8,9,10};
MethodOverload mo=new MethodOverload();
mo.number(num);

}
}
