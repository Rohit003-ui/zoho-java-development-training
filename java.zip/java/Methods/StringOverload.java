import java.util.*;

class StringOverload{

void vehicles(String[] vehicles){
 for(String vec:vehicles)
   System.out.println(vec);
}

void vehicles(String[] vehicles){
 for(String vec:vehicles)
   System.out.println(vec);
}

public static void main(String[] args){

String[] Vehicle={"Bike","Scooty","Car","Lorry","Ev","Auto","Tempo"};

StringOverload obj=new StringOverload();
obj.vehicles(Vehicle);

}
}