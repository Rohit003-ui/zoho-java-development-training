import java.util.*;

class StringMethod{

void vehicles(String[] vehicles){
 for(String vec:vehicles)
   System.out.println(vec);
}


public static void main(String[] args){

String[] Vehicle={"Bike","Scooty","Car","Lorry","Ev","Auto","Tempo"};

StringMethod obj=new StringMethod();
obj.vehicles(Vehicle);

}
}