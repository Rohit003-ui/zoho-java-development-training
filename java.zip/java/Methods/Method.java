import java.util.*;

class Method{

  void number(int[] a){
   for(int i=0;i<a.length;i++)
     System.out.println(a[i]);
 }

 void number(int[] a,int[] b){
  for(int i=0;i<b.length;i++)
     System.out.println(b[i]);
 }

public static void main(String[] args){

int[] num1={1,2,3,4,5,6,7,8,9,10};
int[] num2={11,12,13,14,15,16,17,18,19,20};
Method mo=new Method();
mo.number(num1);

}
}