// Constructor Chaining using the "super" Keyword

// used to call the constructor from the "sub class constructor" to "super class constructor"


import java.util.*;
class A{
 public A(){
   System.out.println("1");
 }
}

class B extends A{
 public B(int x){
   super();
   System.out.println("2");
}
}

class C extends B{
 public C(double a,float b){
   super(100);
   System.out.println("3");
}
}

class D extends C{
 public D(boolean a,char b){
   super(10.1 , 10.2f);
   System.out.println("4");
}
}



class ConChaSuper{
public static void main(String[] args){
 D d1=new D(true,'A');

}
}