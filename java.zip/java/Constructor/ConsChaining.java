
// Constructor Chaining using "this" keyword

// to call the function within the class so using "this" keyword

import java.util.*;
class Demo{
 public Demo(){
  System.out.println("1");
 }

 public Demo(int x){
  this();
  System.out.println("2");
 }

 public Demo(char x,double y){
  this(100);
  System.out.println("1");
 }
}

class ConsChaining{
public static void main(String[] args){

Demo d1=new Demo('A',10.15);

}
}