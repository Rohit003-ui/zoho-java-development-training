import java.util.*;
public class Max{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);

System.out.println("Enter the value of A:");
double a=sc.nextDouble();

System.out.println("Enter the value of B:");
double b=sc.nextDouble();


System.out.println(" ");

if(a>b){
 System.out.println("A is Greater than B");
}

else{
 System.out.println("B is Greater than A");
}


}
}