public class Main{
public static void main(String[] args){

System.out.println("Operators");
System.out.println(" ");
System.out.println("Arithmetic Operators");
System.out.println(" ");

int a=500;
int b=300;
System.out.println("Value of A:"+a);
System.out.println("Value of B:"+b);
System.out.println("Addition of A and B:"+(a+b));
System.out.println("Subtraction of A and B:"+(a-b));
System.out.println("Division of A and B:"+(a/b));
System.out.println("Multiplication of A and B:"+(a*b));
System.out.println("Modulus of A and B:"+(a%b));

System.out.println(" ");
System.out.println("Unary Operators");
System.out.println(" ");
System.out.println("A is decremented by 1:"+(--a));
System.out.println("A ia incremented by 1:"+(++a));
System.out.println("Not A:"+(~a));


System.out.println(" ");
System.out.println("Assignment Operators");
System.out.println(" ");
int c=400;
System.out.println("Value of c:"+c);
System.out.println("400 is Assigned to C:"+c);
System.out.println("100 is Added to the C:"+(c+=100));
System.out.println("100 is Subtracted to the C:"+(c-=100));


System.out.println(" ");
System.out.println("Comparision Operators");
System.out.println(" ");
System.out.println("A is equal to B:"+(a==b));
System.out.println("A is Greater than B:"+(a>b));
System.out.println("A is lesser than B:"+(a<b));
System.out.println("A is lesser than or equal to B:"+(a<=b));
System.out.println("A is Greater than or equal to B:"+(a>=b));
System.out.println("A is Not equal to B:"+(a!=b));



System.out.println(" ");
System.out.println("Logical Operators");
System.out.println(" ");
System.out.println("A is equal to B and A is greater than B:"+((a==b)&&(a>=b)));
System.out.println("A is equal to B or A is lesser than B:"+((a==b)||(a>=b)));
System.out.println("Not of A is Greater than or equal to B:"+(!(a>=b)));


System.out.println(" ");
System.out.println("Ternery Operator");
System.out.println(" ");
System.out.println("A is Greater than B then print A:"+((a>b)?a:b));


System.out.println(" ");
System.out.println("Bitwise Operator");
System.out.println(" ");
System.out.println("A is equal to B and A is greater than B:"+((a==b)&(a>=b)));
System.out.println("A is equal to B or A is lesser than B:"+((a==b)|(a>=b)));



System.out.println(" ");
System.out.println("Instace OF Operator");
System.out.println(" ");
String str="Hello";
System.out.println(str instanceof String);

System.out.println(" ");
System.out.println("Operator Precidence");
System.out.println(" ");
System.out.println(5+(-1/2));

System.out.println(" ");
System.out.println("Shift Operator");
System.out.println(" ");
System.out.println("Left shift of a"+(a<<2));
System.out.println("Right shift of a"+(a>>2));
System.out.println("Left shift of a"+(a>>>2));
}
}