public class Bitwise{
public static void main(String[] args){
int a =  0b1000001;   //65
int b =  0b0001001;  //9

System.out.println(" a & b:"+ (a&b));   
System.out.println(" a | b:"+ (a|b));   
System.out.println(" a ^ b:"+ (a^b));   
System.out.println(" a>>2:"+ (a>>2));     
System.out.println(" a<<1:"+ (a<<1));    
System.out.println(" a>>>2:"+ (a>>2)); 

        int c = 0b0101;  //5
        int d = 0b0011;  //3
        int e = 0b0010;  //2
        System.out.println( c/d );
        System.out.println( (c&e)/c );
    
  
}
}
