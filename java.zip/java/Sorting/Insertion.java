
class Insertion{

  void sort(int[] arr,int n){
   for(int i=0;i<n;i++){
     int temp=arr[i];
     int j=i-1;
     while(j>=0 && arr[j]>temp){
       arr[j+1]=arr[j];
       j--;
     }
     arr[j+1]=temp;
   }
   for(int i=0;i<n;i++){
     System.out.print(arr[i]+" ");
   }
  }

public static void main(String[] args){
int[] arr={0,3,5,4,7,6,9,1,8};
Insertion i=new Insertion();
i.sort(arr,arr.length);
} 
}



/*

class Insertion{

  void sort(char[] arr,int n){
   for(int i=0;i<n;i++){
     char temp=arr[i];
     int j=i-1;
     while(j>=0 && arr[j]>temp){
       arr[j+1]=arr[j];
       j--;
     }
     arr[j+1]=temp;
   }
   for(int i=0;i<n;i++){
     System.out.print(arr[i]+" ");
   }
  }

public static void main(String[] args){
char[] arr={'C','A','E','B','D'};
Insertion i=new Insertion();
i.sort(arr,arr.length);
} 
}

*/


