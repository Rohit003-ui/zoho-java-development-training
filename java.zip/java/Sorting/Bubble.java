
class Bub{

 void sort(int[] arr,int n){
   for(int i=0;i<n-1;i++){
      for(int j=0;j<n-i-1;j++){
	if(arr[j]>arr[j+1]){

/*        int temp=arr[j];
  	  arr[j]=arr[j+1];
	  arr[j+1]=temp;
*/
           arr[j]=arr[j]+arr[j+1];
           arr[j+1]=arr[j]-arr[j+1];
           arr[j]=arr[j]-arr[j+1];
        }
      }
    }
  for(int i=0;i<arr.length;i++){
    System.out.print(arr[i]+ " ");
 }
}
}
public class Bubble {
public static void main(String[] args){
int[] arr={2,5,3,4,6,9,1,8,0};
Bub b=new Bub();
b.sort(arr,arr.length);

}
}