import java.util.*;
class Selection{
 void sort(int[] arr,int n){
  for(int i=0;i<n-1;i++){
    int temp=i;
    for(int j=i+1;j<n;j++){
       if(arr[j]<arr[temp]){
         temp=j;
       } 
    }
  int t=arr[i];
  arr[i]=arr[temp];
  arr[temp]=t;
  }
  for(int i=0;i<n;i++)  System.out.print(" "+arr[i]);
 }

public static void main(String[] args){
int[] arr={3,5,7,2,4,6,1};
Selection s=new Selection();
s.sort(arr,arr.length);

}
}