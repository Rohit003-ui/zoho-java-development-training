import java.util.*;

public class Nprime {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);

System.out.println("Enter the Starting Number:");
int st=sc.nextInt();

System.out.println("Enter the Ending Number:");
int end=sc.nextInt();

int count=0;

for(int n=st;n<=end;n++) {
   if(n<=1) continue;
   int factorCount=0;

    for (int i=2;i*i<=n;i++) {
        if(n%i==0) {
           factorCount++;
           break;
     }
}

      if(factorCount == 0) {
         count++;
      }
   }

        System.out.println("Total Prime Numbers is : " + count);
    }
}
