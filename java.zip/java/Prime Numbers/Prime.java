import java.util.*;
public class Prime{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
int i,count=0;
System.out.println("Enter the Number:");
int n=sc.nextInt();

if(n<=1){
 System.out.println(n+ " is Not a Prime Number");
} 
else{

 for(i=2;i<=n/2;i++){
   if(n%i==0){
     count++;
     break;
   }
 }
 if(count==0){
  System.out.println(n +" is a prime Number");
 } 
 else{
   System.out.println(n +" is a Not prime Number");
 }

}
}
}