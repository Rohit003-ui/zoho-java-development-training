import java.util.*;

public class Nprime {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);

System.out.println("Enter the Starting Number:");
int st=sc.nextInt();

System.out.println("Enter the Ending Number:");
int end=sc.nextInt();

int count=0,n=st,i=2;

while(n<=end) {
   if(n<=1) continue;
   int factorCount=0;

    while(i*i<=n) {
        if(n%i==0) {
           factorCount++;
	   i++;
           break;
     }n++;
}

      if(factorCount == 0) {
         count++;
      }
   }

        System.out.println("Total Prime Numbers is : " + count);
    }
}
