
class Calculator{
int add(int a,int b){
 return a+b;
}

int sub(int a,int b){
 return a-b;
}

int mul(int a,int b){
 return a*b;
}

double div(int a,int b){
 return (b!=0)?(a/b):0;
}

int mod(int a,int b){
 return a%b;
}


double power(double a,double b){
 return Math.pow(a,b);
}

double sqrt(double a){
 return Math.sqrt(a);
}

double cube(double x){
 return Math.pow(x,3);
}

}