import java.util.*;
class Main{
public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
Calculator c = new Calculator();
int ch;

do{
System.out.println("");
System.out.println("1. Addition");
System.out.println("2. Subtraction");
System.out.println("3. Multiplication");
System.out.println("4. Division");
System.out.println("5. Modulus");
System.out.println("6. Power");
System.out.println("7. Square");
System.out.println("8. Cube");
System.out.println("9. Exit");
System.out.println("");
System.out.print("Enter your choice: ");
ch=sc.nextInt();


switch(ch){
 case 1:
   System.out.println("Enter the Value of Number 1: ");
   int n1=sc.nextInt();
   System.out.println("Enter the Value of Number 2: ");
   int n2=sc.nextInt();
   System.out.println("Addition: " + c.add(n1,n2));
System.out.println("");
   break;

 case 2:
   System.out.println("Enter the Value of Number 1: ");
   int n3=sc.nextInt();
   System.out.println("Enter the Value of Number 2: ");
   int n4=sc.nextInt();
   System.out.println("Subtraction: " + c.sub(n3,n4));
System.out.println("");
   break;

 case 3:
   System.out.println("Enter the Value of Number 1: ");
   int n5=sc.nextInt();
   System.out.println("Enter the Value of Number 2: ");
   int n6=sc.nextInt();
   System.out.println("Multiplication: " + c.mul(n5,n6));
System.out.println("");
   break;

 case 4:
   System.out.println("Enter the Value of Number 1: ");
   int n7=sc.nextInt();
   System.out.println("Enter the Value of Number 2: ");
   int n8=sc.nextInt();
   System.out.println("Division: " + c.div(n7,n8));
System.out.println("");
   break;

 case 5:
   System.out.println("Enter the Value of Number 1: ");
   int n9=sc.nextInt();
   System.out.println("Enter the Value of Number 2: ");
   int n10=sc.nextInt();
   System.out.println("Modulus: " + c.mod(n9,n10));
System.out.println("");
   break;

 case 6:
   System.out.println("Enter the Value of Base: ");
   double n11=sc.nextDouble();
   System.out.println("Enter the Value of Power: ");
   double n12=sc.nextDouble();
   System.out.println("Power: " + c.power(n11,n12));
System.out.println("");
   break;

 case 7:
   System.out.println("Enter the Value of Number to Square: ");
   double n13=sc.nextDouble();
   System.out.println("Square: " + c.sqrt(n13));
System.out.println("");
   break;

 case 8:
   System.out.println("Enter the Value of Base: ");
   double n14=sc.nextDouble();
   System.out.println("Cube of "+ n14+ " is: " + c.cube(n14));
System.out.println("");
   break;

}
}while(ch<0 && ch>=8);

 }
}