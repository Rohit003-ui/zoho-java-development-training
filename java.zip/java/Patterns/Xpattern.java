import java.util.*;
public class Xpattern{
public static void main(String[] args) {

Scanner sc=new Scanner(System.in);
System.out.println("Enter the Number for Rows and Columns:");
int n=sc.nextInt();
    
  for(int i=0;i<=n;i++){
    for(int j=1;j<=n;j++){
      if(i==j||i+j==n+1){
        System.out.print("*");
        System.out.print(" ");
      }
      else System.out.print(" ");
    }
     System.out.println();
  }
    
}
}
