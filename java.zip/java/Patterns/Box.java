import java.util.*;
public class Box{
  public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the Number for Rows:");
    int i=sc.nextInt();
    System.out.println("Enter the Number for Column:");
    int j=sc.nextInt();
    int[][] n=new int[i][j];
    
    for(int a=0;a<i;a++){
     for(int b=0;b<j;b++){
      System.out.print("*");
      System.out.print(" ");
     }
     System.out.println(" ");
    }
    
  }
}
