import java.util.*;

public class Sumofnum{
public static void main(String[] args) {

Scanner sc=new Scanner(System.in);
System.out.println("Enter the Number:");
double n=sc.nextDouble();

double sum=0;

while(n>0){
 double add=n%10;
 sum+=add;
 n=n/10;
}
System.out.println(sum);

}
}
