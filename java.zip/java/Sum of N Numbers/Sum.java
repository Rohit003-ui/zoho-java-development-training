import java.util.*;
class Sum {
    public static void main(String[] args) {
        int sum=0;
        System.out.println("Enter the Number:");
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
    if(n<1){
	System.out.println("Enter the Positive Number");
    }
    else{
        for(int i=0;i<=n;i++){
             sum +=i;
        }
        System.out.println("Sum of N Numbers:"+sum);
     }
    }
}