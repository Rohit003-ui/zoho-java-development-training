import java.util.*;

public class Rev{
public static void main(String[] args) {

Scanner sc=new Scanner(System.in);
System.out.println("Enter the Number:");
int n=sc.nextInt();
int rev=0;

while(n>0){
 rev=rev*10+n%10;
 n/=10;
}
 System.out.println("The Reversed Number is "+rev);

}
}
