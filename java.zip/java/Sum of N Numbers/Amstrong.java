import java.util.*;

public class Amstrong{
public static void main(String[] args) {

Scanner sc=new Scanner(System.in);
System.out.println("Enter the Number:");
int n=sc.nextInt();

int count=0,sum=0,a=0,b=0;
int c=n;

while(n>0){
 count++;
 n/=10;
} 
 
while(c>0){
a=c%10;

 while(count>0){
  b*=a;
  count--;
 }

sum+=b;
c/=10;
}
System.out.println("Addition of Numbers "+sum);

}
}
