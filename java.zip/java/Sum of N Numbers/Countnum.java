import java.util.*;

public class Countnum{
public static void main(String[] args) {

Scanner sc=new Scanner(System.in);
System.out.println("Enter the Number");
int n=sc.nextInt();
int sum=0,count=0;

while(n>0){
 sum=sum*10+n%10;
 n/=10;
 count++; 
}

System.out.println("The Count is "+count);

}
}
