public class Bodmas{
public static void main(String[] args){
System.out.println(5*2+2);
}
}

