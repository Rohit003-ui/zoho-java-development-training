import java.util.*;
public class maximum{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);

System.out.println("Enter the value of A:");
double a=sc.nextDouble();

System.out.println("Enter the value of B:");
double b=sc.nextDouble();


System.out.println("Enter the value of C:");
double c=sc.nextDouble();

System.out.println("Enter the value of d:");
double d=sc.nextDouble();
System.out.println(" ");

if(a>=b && a>=c && a>=d){
 System.out.println("A is Greater than B, C and D");
}

else if(b>=a && b>=c && b>=d){
 System.out.println("B is Greater than A, C and D");
}

else if(c>=a && c>=b && c>=d){
 System.out.println("C is Greater than A, B and D");
}


else{
 System.out.println("D is Greater than A, B and C");
}


}
}