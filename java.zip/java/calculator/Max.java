import java.util.*;
public class Max{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);

System.out.println("Enter the value of A:");
double a=sc.nextDouble();

System.out.println("Enter the value of B:");
double b=sc.nextDouble();


System.out.println("Enter the value of C:");
double c=sc.nextDouble();
System.out.println(" ");

if(a>=b && a>=c){
 System.out.println("A is Greater than B and C");
}

else if(b>=a && b>=c){
 System.out.println("B is Greater than A and C");
}

else{
 System.out.println("C is Greater than A and B");
}


}
}