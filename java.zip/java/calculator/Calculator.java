import java.util.Scanner;

public class Calculator{
public static void main(String[] args){

Scanner sc=new Scanner(System.in);

System.out.println("Enter the Value of A:");
double a=sc.nextDouble();

System.out.println("Enter the Value of B:");
double b=sc.nextDouble();

System.out.println("Enter the Opporator:");
char c=sc.next().charAt(0);

if(c =='+'){
	System.out.println("Addition of "+a+" and "+b+" is "+(a+b));
}
else if(c =='-'){
	System.out.println("Subtraction of "+a+" and "+b+" is "+(a-b));
}
else if(c =='*'){
	System.out.println("Multiplication of "+a+" and "+b+" is "+(a*b));
}
else if(c =='/'){
	System.out.println("Division of "+a+" and "+b+" is "+(a/b));
}
else if(c =='%'){
	System.out.println("Modulus of "+a+" and "+b+" is "+(a%b));
}
else{
	System.out.println("Invalid Operator");
}
}
}