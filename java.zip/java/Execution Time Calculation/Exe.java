import java.util.*;
public class Exe{
public static void main(String[] args) {

long starttime = System.currentTimeMillis();
System.out.println(starttime);

for (int i = 0; i < 100; i++) {
 System.out.println(i);
}

long endtime = System.currentTimeMillis();
System.out.println(endtime);

System.out.println("Execution time:" + (endtime - starttime) + " milliseconds");
}
}