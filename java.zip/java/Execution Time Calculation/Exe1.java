import java.util.*;
public class Exe1{
public static void main(String[] args) {

long starttime = System.currentTimeMillis();
System.out.println(starttime);
int i=0;
do{
 System.out.println(i);
i++;
}while(i<100);

long endtime = System.currentTimeMillis();
System.out.println(endtime);

System.out.println("Execution time:" + (endtime - starttime) + " milliseconds");
}
}