import java.util.*;

class Student{
 public String name="Rohit";
 int roll_no=45;
 int marks=90;
 
}

class Teacher{
 public String Name="Jhon"; 
 protected int id=123;
 protected int salary=30000;
  
}

class Principal{
 private int id=11;
 private int number=1234567890;

   void disp(){
     System.out.println("Principal ID: "+id);
     System.out.println("Principal Number: "+number);
   }
}

public class Main{
public static void main(String[] args){
 
 Student st=new Student();
 System.out.println ("Student Name: "+ st.name);
 System.out.println ("Student Roll No: "+ st.roll_no);
 System.out.println ("Student Mark: "+ st.marks);
 System.out.println("\n");

 Teacher t=new Teacher();
 System.out.println("Teacher Name: "+t.Name);
 System.out.println("Teacher ID: "+t.id);
 System.out.println("Teacher Salary: "+t.salary);
 System.out.println("\n");
 
 Principal p=new Principal();
     //System.out.println("Principal ID: "+p.id);
     //System.out.println("Principal Number: "+p.number);
 p.disp();
 System.out.println("\n");
}
}
