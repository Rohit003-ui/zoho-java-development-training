import java.util.*;

class Main{
public static void main(String[] args){

Scanner sc=new Scanner(System.in);
Array a=new Array(8);


a.insert(0,23);
a.insert(1,24);
a.insert(2,25);
a.insert(3,26);
a.insert(4,27);
a.insert(5,28);
a.insert(6,29);
a.insert(7,30);
a.display();

System.out.println(" ");
System.out.println("Replace of Element");
a.replace(2,45);
a.display();


System.out.println(" ");
System.out.println("Addition of Element");
a.add(2,80);
a.display();


System.out.println(" ");
System.out.println("Searching of Element by Value");
a.search(26);
a.display();

System.out.println(" ");
System.out.println("Searching of Element by Index");
a.searchindex(3);
a.display();

System.out.println(" ");
System.out.println("Deleting of Element by Index");
a.delete(2);
a.display();

System.out.println(" ");
System.out.println("Deleting of Element by value");
a.del(26);
a.display();


System.out.println(" ");
System.out.println("Remove by First");
a.removebystart();
a.display();


System.out.println(" ");
System.out.println("Remove by Center");
a.deletebycenter();
a.display();

System.out.println(" ");
System.out.println("Resizing Array");
a.insert(4,40);
a.insert(5,50);
a.insert(6,60);
a.insert(7,70);
a.insert(8,80);
a.insert(9,90);
a.insert(10,100);
a.insert(11,110);
a.insert(12,120);
a.insert(13,130);
a.insert(14,140);
a.insert(15,150);
a.insert(16,160);
a.insert(17,170);
a.insert(18,180);
a.insert(19,190);
a.insert(20,200);

a.display();

System.out.println(" ");
System.out.println("Linear Search");
a.linearSearch(160);
a.display();

System.out.println(" ");
System.out.println("Binary Search");
int s=130;
a.binarysearch(s);


System.out.println(" ");
System.out.println(" ");
System.out.println("Bubble Sort");
a.bubblesort();

System.out.println(" ");
System.out.println(" ");
System.out.println("Insertion Sort");
a.insertionsort();


a.insert(21,100);
System.out.println(" ");
System.out.println(" ");
System.out.println("Check Dupicates");
a.checkdupicates();
a.display();


System.out.println(" ");
System.out.println(" ");
System.out.println("Array Comparision");
int[] arr1={23,27,29,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200,100};
a.arrcompare(arr1);


System.out.println(" ");
System.out.println(" ");
System.out.println("Quick Sort");
System.out.println("1. Assending Order");
System.out.println("2. Descending Order");
System.out.println(" ");
System.out.println("Enter Your Choice:");
int ch=sc.nextInt();
switch(ch){
 case 1:
   int[] brr={5,6,2,3,1,4,8};
   a.quicksort(brr,0,brr.length-1);
   System.out.println("Quick Sort");
   for(int i=0;i<brr.length;i++) System.out.println(brr[i]+" ");
   break;
 case 2:
  int[] brr1={5,6,2,3,1,4,8};
  a.desquicksort(brr1,0,brr1.length-1);

  //for(int i=0;i<brr1.length;i++) System.out.println(brr1[i]+" ");
  break;
 default:
  System.out.println("Enter the Valid choise");
}
 
}
}