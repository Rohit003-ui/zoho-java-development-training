class Array{

int[] arr;
int size;
int capacity;
 
  Array(int capacity){
   arr=new int[capacity];
   this.capacity=capacity;
   size=0;
  }


 
  void insert(int index,int element){
    if(index<0 || index>size){
	System.out.println("Array is full");
    }
    if(size>=capacity){
      resize();
    }
    for(int i=size-1;i>index;i--){
	arr[i]=arr[i-1];
     }
    arr[index]=element;
    size++;
  }




   void add(int index,int element){
     if(index<0 || index>size) System.out.println("Invalid Index");
     System.out.println("Element Added at index \"" + index + "\" is \"" + element+"\"");
     for(int i=size-1;i<index;i--){
      if(arr[i]==index){
	arr[i]=arr[i-1];
      }
     }
      arr[index]=element;
    //  size++;
   }





  void replace(int index,int element){
     if(index<0 || index>=size) System.out.println("Invalid Index");
     System.out.println("Replaced Element at index \""+index+ "\" is \""+ element+"\"");
     arr[index]=element;
  }
  





  void search(int element){
    for(int i=0;i<size;i++){
      if(arr[i]==element){
        System.out.println("The Element \""+element+"\" is found in the index at: \""+i+"\"");
      }
    }
  }



  void searchindex(int index){
   if(index<0 || index>=size) System.out.println("Invalid Index");
   System.out.println("Element present at index \"" + index + "\" is \"" + arr[index]+"\"");
  }




   void delete(int index){
     if(index<0 || index>=size) System.out.println("Invalid Index");
     System.out.println("Element Delete at index \"" + index + "\" is \"" + arr[index]+"\"");
     for(int i=index;i<size-1;i++){
      arr[i]=arr[i+1];
     }size--;
   }
  

 
   void del(int element){
     for(int i=0;i<size-1;i++){
      if(arr[i]==element){
	delete(i);
       }
     }
   }





  void removebystart(){
   for(int i=1;i<size;i++){
     arr[i]=arr[i+1];
    
  }
  size--;
  }

/*
    int found=-1;
     for(int i=0;i<size;i++) {
     if(arr[i]==element){
        found=i;
        break;
     }
     }
   if(found==-1){
     System.out.println("Value not found");
    }
   for(int i=found;i<size-1;i++){
     arr[i]=arr[i+1];
   }
   size--;
   }
*/   
  


 void deletebycenter(){
 int mid=size/2; 
  for(int i=mid;i<size;i++){
   arr[i]=arr[i+1];    
  } 
   size--;
 }

 



  void resize(){
   capacity*=2;
   int[] newArr= new int[capacity];
   for(int i=0;i<arr.length;i++){
     newArr[i]=arr[i];
   }
   arr=newArr;
  } 





  void display(){
     System.out.print("Array Elements are: ");
    for(int i=0;i<size;i++)
       System.out.print(arr[i]+" ");
    System.out.println(" ");
   }




 void linearSearch(int ele){
 boolean found=false;
 for(int i=0;i<arr.length;i++){
   if(arr[i]==ele){
    System.out.println("Element \""+arr[i]+"\" Found at Index \""+i+"\"");
    found=true;
    break;
   }
 }
 if(found==false){
  System.out.println("Element Not Found");
 }
 } 



 void binarysearch(int ele){
  int n=size;
  for(int i=0;i<n-1;i++){
      for(int j=0;j<n-i-1;j++){
         if( arr[j]>arr[j+1]){
           arr[j]=arr[j]+arr[j+1];
           arr[j+1]=arr[j]-arr[j+1];
           arr[j]=arr[j]-arr[j+1];
         }
      }
   }
 int l=0;
 int r=arr.length-1;
 while(l<=r){
  int mid=(l+r)/2;
  if(arr[mid]==ele){
    System.out.println("Element \""+ele+"\" Found at Index \""+mid+"\"");
    break;
  }
  else if(arr[mid]>ele)
    r=mid-1;
  else
    l=mid+1;
 }
 System.out.print("Array Elements are: ");
 for(int i=0;i<n;i++){
  System.out.print(" "+arr[i]);
 }
 }


 void bubblesort(){
  int n=size;
   for(int i=0;i<n-1;i++){
      for(int j=0;j<n-i-1;j++){
	if(arr[j]<arr[j+1]){
          int temp=arr[j];
  	  arr[j]=arr[j+1];
	  arr[j+1]=temp;
        }
      }
    }
  System.out.print("Array Elements are: ");
  for(int i=0;i<n;i++){
    System.out.print(arr[i]+ " ");
  }
 }



  void insertionsort(){
   int n=size;
   for(int i=0;i<n;i++){
     int temp=arr[i];
     int j=i-1;
     while(j>=0 && arr[j]>temp){
       arr[j+1]=arr[j];
       j--;
     }
     arr[j+1]=temp;
   }
   System.out.print("Array Elements are: ");
   for(int i=0;i<n;i++){
     System.out.print(arr[i]+" ");
   }
  }


 void checkdupicates(){
  int n=size;
  boolean found=false;
  for(int i=0;i<n;i++){
    for(int j=i+1;j<n;j++){
      if(arr[i]==arr[j]){
        System.out.println("Duplicate Element is "+arr[i]);
        found = true;
        break;
        
      }
    } 
  }
 if(!found)
 System.out.println("Dupicate Element Not Found in the Array");
 }



 void arrcompare(int[] arr1){
  int i=0;
  boolean found= false;
  System.out.print("Array 1 Elements are: ");
   for(i=0;i<size;i++){
     System.out.print(arr[i]+" ");
   }
  System.out.println(" ");
   System.out.print("Array 2 Elements are: ");
   for(i=0;i<arr1.length;i++){
     System.out.print(arr1[i]+" ");
   }
  System.out.println(" ");
  for(i=0;i<arr.length;i++){
    if(arr[i]==arr1[i]){
       found=true;
       break;
    }
  }
  if(found==true) System.out.println("Array Elements are same");
  else System.out.println("Array Elements is Not Same");
  }



int partition(int[] arr,int low,int high){
/*
  Scanner sc=new Scanner(System.in);
  System.out.println("1. Assending Order");
  System.out.println("2. Descending Order");
  System.out.println(" ");
  System.out.println("Enter Your Choice:");
  String ch=sc.nextInt==1 ? "asc": "des";
*/

  int pivot=arr[low];
  int i=low;
  int j=high;

  while(i<j){
    while(i<=high && arr[i]<=pivot){
      i++;
    }
    while(j>=low && arr[j]>pivot){
      j--;
    }
   if(i<j){
    int temp=arr[i];
    arr[i]=arr[j];
    arr[j]=temp;
   }
  }
    int temp=arr[j];
    arr[j]=arr[low];
    arr[low]=temp;
   return j;
 }

 void quicksort(int[] arr,int low,int high){
  if(low<high){
    int pivot= partition(arr,low,high);
    quicksort(arr,low,pivot-1);
    quicksort(arr,pivot+1,high);
  }
  
 }
  
void desquicksort(int[] arr,int low,int high){

}


}

