
public class Mnumber {


/*
 // Finding the Missing Number in an Array
 void missingNumber(int[] arr){
      int exp=0; 
      int n=arr.length+1;
      int sum=0;
      
      exp=n*(n+1)/2;
        
      for(int i=0;i<arr.length;i++){
        sum+=arr[i];
      }
     int tot=exp-sum;
    System.out.println(tot);
}

*/

/*
   // Find the Duplicate Element and count it in the array
   
  void frequency(int[] arr){
   int count=0;    
   int n=arr.length;
 
   for(int i=0;i<n;i++){
    boolean visited=true;
     for(int j=0;j<n;j++){
      if(arr[i]==arr[j])  count++;
     }
   for(int k=0;k<i;k++){
     if(arr[k]==arr[i]){  
      visited=false; 
      break;
     }
   }
   if(visited){
   System.out.print("["+arr[i]+","+count+"] ");
   System.out.print(" ");
   }
    count=0;
   
   }

  }

*/


 void large3(int[] arr){
  int n=arr.length;
  int max=0;
  int[] a={};
  while(a[3]<=3){
  for(int i=0;i<n;i++){
      if(arr[i]>max){      
         max=a[i];  
      }
  }
  }
 System.out.println("Third largest Element in the array is "+a[n]);

 }


    public static void main(String[] args) {

      int[] arr={1,1,2,3,4,3,5};

      Mnumber m=new Mnumber();

     // m.missingNumber(arr);

     // m.frequency(arr);
    
      m.large3(arr);

    }


}