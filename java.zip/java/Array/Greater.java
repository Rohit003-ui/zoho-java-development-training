class Greater{

 void odd(int[] arr){
 int even=1;
 int odd=0;
  for(int i=0;i<arr.length;i++){
    if((arr[i]%2)==0){
     even*=arr[i];
    }
    else{
     odd+=arr[i];
    }
  }
  System.out.println("Odd "+odd);
  System.out.println("Even "+even);
 }
 

  void max(int[] arr){
  int max=0;
  int low=0;
  for(int i=0;i<arr.length;i++){
    for(int j=1;j<arr.length;j++){
       if(arr[i]<arr[j]){
         max=arr[j];
       }
       else{
         low=arr[i];
       }
    }
  }
 System.out.println("Largest Element in the Array: "+max);
 System.out.println("Smallest Element in the Array: "+low);
 }






/*

 void pair(int[] arr){
  int n=arr.length;
   if(n/2!=0){
   for(int i=0;i<n/2;i++){
   int max=0;
   int low=0;
     for(int j=0;j<n;j++){
        if(arr[j]>arr[max]){
          max=j;
        }
     }
     for(int j=0;j<n;j++){
       if(arr[j]<arr[low]){
        low=j;
     }
    }
    System.out.println(arr[low]+" <-> "+arr[max]);
    arr[max]=0;
    arr[low]=0;
   }
 }
} 

*/










void pair(int[] arr){

int size=arr.length-1;
int i=0;
 while(size>i){
   int max=i;
   int min=i;
    for(int j=i;j<=size;j++){
         
       if(arr[j]>arr[max]) max=j;
       if(arr[j]<arr[min]) min=j;

    }

   System.out.println(arr[min]+" <-> "+arr[max]);

    int temp=arr[max];
    arr[max]=arr[size];
    arr[size]=temp;

   
    int t=arr[i];
    arr[i]=arr[min];
    arr[min]=t;
    i++;
    size--;
  for(int k=0;k<arr.length;k++) System.out.print(arr[k]+" ");
 }

}






public static void main(String[] args){
int[] arr={13,7,4,39,22,52};

/*
4 7 13 22 39 52

4 <-> 52
7 <-> 39
13 <-> 22

*/

Greater g=new Greater();

//g.odd(arr);

//g.max(arr);

g.pair(arr);
}

}










