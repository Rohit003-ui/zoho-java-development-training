class SumArray{

 void sum(int[] arr,int n){
  int sum=0;
  for(int i=0;i<n;i++){
    sum+=arr[i];
  }
 System.out.println("The Sum of Array is "+ sum);
 }

public static void main(String[] args){
int[] arr={12,45,34,78,34};
SumArray s=new SumArray();
s.sum(arr,arr.length); 
}
}