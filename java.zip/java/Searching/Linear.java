
class Linear{
 void search(int[] arr,int n,int ele){
   int flag=0;
   for(int i=0;i<n;i++){
    if(arr[i]==ele){
	flag=1;
    }
   }
  if(flag==1) System.out.println("The Element \""+ele+"\" is found");
  else System.out.println("Element is not present in the Array");
 }

public static void main(String[] args){
int[] arr={5,7,8,22,11};
Linear l=new Linear();
int s=22;
l.search(arr,arr.length,s);
}
}