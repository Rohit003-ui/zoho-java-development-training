class RevArray{

 void rev(int[] arr,int n){
  for(int i=n-1;i>=0;i--){
   System.out.print(" "+arr[i]);
  }
 }

public static void main(String[] args){
int[] arr={12,45,34,78,38};
RevArray s=new RevArray();
s.rev(arr,arr.length); 
}
}