
/*

class Duplicate{
 void check(int[] arr,int n,int c){
  int found=0;
   for(int i=0;i<n;i++){
     if(arr[i]==c){
        found=1;
     }
   }
   if(found==1){
     System.out.println("Duplicate value Found");
   }
   else{
      if (n<arr.length) {
        arr[n] = c;
        n++;
       System.out.println("Element added successfully");
      }
   }
 System.out.println("Array Elemenets are");
 for(int i=0;i<n;i++){
  System.out.print(" "+arr[i]);
 }
 }

public static void main(String[] args){
int[] arr=new int[10];

arr[0]=54;
arr[1]=63;
arr[2]=4;
arr[3]=78;
arr[4]=19;
arr[5]=768;
arr[6]=65;

int l=7;
int c=786;
Duplicate d=new Duplicate();
d.check(arr,l,c); 
}
}

*/













class Duplicate{

 void check(int[] arr,int n){
  boolean found=false;
  for(int i=0;i<n;i++){
    for(int j=i+1;j<n;j++){
      if(arr[i]==arr[j]){
        System.out.println("Duplicate Element is "+arr[i]);
        found = true;
        break;
        
      }
    } 
  }
 if(!found)
 System.out.println("Dupicate Element Not Found in the Array");
 }

public static void main(String[] args){
int[] arr={54,63,4,78,19,768,63,78};
int n=8;
Duplicate d=new Duplicate();
d.check(arr,n); 
}
}




