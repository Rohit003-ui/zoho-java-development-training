/*

class Binary{
 void search(int[] arr,int n,int ele){
  for(int i=0;i<n-1;i++){
      for(int j=0;j<n-i-1;j++){
         if( arr[j]>arr[j+1]){
           arr[j]=arr[j]+arr[j+1];
           arr[j+1]=arr[j]-arr[j+1];
           arr[j]=arr[j]-arr[j+1];
         }
      }
   }
 int l=0;
 int r=arr.length-1;
 while(l<=r){
  int mid=(l+r)/2;
  if(arr[mid]==ele){
    System.out.println("Element is found at "+mid);
    break;
  }
  else if(arr[mid]>ele)
    r=mid-1;
  else
    l=mid+1;
 }
 }

public static void main(String[] args){
int[] arr={4,6,3,5,8,7};
Binary b=new Binary();
int s=7;
b.search(arr,arr.length,s);
//3 4 5 6 7 8 
}
}

*/





class Binary{

 void search(int[] arr,int n,int ele){
   int mid=arr.length/2;
   for(int i=0;i<n-1;i++){
      for(int j=0;j<n-i-1;j++){
         if( arr[j]>arr[j+1]){
           arr[j]=arr[j]+arr[j+1];
           arr[j+1]=arr[j]-arr[j+1];
           arr[j]=arr[j]-arr[j+1];
         }
      }
   }
   while(0<=(arr.length)){
     if(arr[mid]==ele) { System.out.println("Element \""+ele+"\" found at Position: "+ mid); break;}
     else if(arr[mid]>ele){ mid--;}
     else{ mid++;}     
   }
 }

public static void main(String[] args){
int[] arr={4,6,3,5,8,7};
Binary b=new Binary();
int s=7;
b.search(arr,arr.length,s);
//3 4 5 6 7 8 
}
}




