import java.util.*;

public class Mark{
public static void main(String[] args) {

Scanner sc=new Scanner(System.in);
System.out.println("Enter the Mark:");
int n=sc.nextInt();

if(n>=90 && n<=100) System.out.println("A Grade");

else if(n>=80 && n<=89) System.out.println("B Grade");

else if(n>=70 && n<=79) System.out.println("C Grade");

else if(n>=60 && n<=69) System.out.println("D Grade");

else if(n<=59 && n>=0) System.out.println("Fail");

else System.out.println("Enter a Valid Number");


}
}
