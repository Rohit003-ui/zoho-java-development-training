import java.util.*;

public class Divisible{
public static void main(String[] args) {

Scanner sc = new Scanner(System.in);

System.out.print("Enter the number to check:");
int n=sc.nextInt();

System.out.print("Enter first divisor: ");
int d1=sc.nextInt();

System.out.print("Enter second divisor: ");
int d2=sc.nextInt();

if (n%d1==0 && n%d2==0) {
  System.out.println(num + " is Divisible by both " + d1 + " and " + d2);
}
else{
  System.out.println(num + " is Not Divisible by both " + d1 + " and " + d2);
}

}
}
