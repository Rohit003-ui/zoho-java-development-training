import java.util.*;

public class Electricity{
public static void main(String[] args) {

Scanner sc=new Scanner(System.in);
System.out.println("Enter the Unit:");
int unit=sc.nextInt();

System.out.println("Enter the Rate:");
double rate=sc.nextDouble();

System.out.println("Enter the Fixed Charge:");
double fc=sc.nextDouble();

System.out.println("Enter the Tax:");
double tax=sc.nextDouble();

double total=(unit*rate)+fc+tax;

 System.out.println("Electricity Bill is "+total);
}
}
