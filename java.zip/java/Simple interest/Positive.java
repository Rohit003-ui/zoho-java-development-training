import java.util.*;
public class Positive{
public static void main(String[] args){

Scanner sc=new Scanner(System.in);

System.out.println("Enter the Number:");
int n=sc.nextInt();

if(n<0){
 System.out.println("It is a Negative Number");
}
else if(n>0){
System.out.println("It is a Positive Number");
}

else{
System.out.println("You have Entered Zero");
}

}
}