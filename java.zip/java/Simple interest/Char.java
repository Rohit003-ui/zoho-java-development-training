import java.util.*;

public class Char{
public static void main(String[] args) {

Scanner sc=new Scanner(System.in);
System.out.println("Enter the Charecter:");
char ch=sc.next().charAt(0);

ch=Character.toLowerCase(ch);
if((ch>='a' && ch<='z')){
 switch(ch){

  case 'a':
  case 'e':
  case 'i':
  case 'o':
  case 'u':
    System.out.println(ch+" is a Vowel");
    break;
  default:
    System.out.println(ch+" is a Consonent");
    break;
  
 }
}
else System.out.println("Enter a Valid Input");

}
}
