import java.util.*;
public class Voting{
public static void main(String[] args){

Scanner sc=new Scanner(System.in);

System.out.println("Enter the Number:");
int n=sc.nextInt();

if(n<1){
 System.out.println("It is a Negative Number");
}
else if(n<18){
System.out.println("You are Not Eligible to Vote");
}

else{
System.out.println("You are Eligible to Vote");
}

}
}