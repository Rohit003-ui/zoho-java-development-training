import java.util.*;

public class Checksym{
public static void main(String[] args) {

Scanner sc=new Scanner(System.in);
System.out.println("Enter the Character:");
char ch=sc.next().charAt(0);

ch=Character.toLowerCase(ch);

switch(ch){
  case 'a','e','i','o','u':
     System.out.println("It is a Vowel");
     break;
   default:
      if (ch >='0' && ch<='9') {
         System.out.println("It is a Digit");
      }
                
      else if((ch>='a' && ch<='z')) {
        System.out.println("It is a Consonant");
      }
       
       else {
         System.out.println("It is a Symbol");
       }
}


}
}
