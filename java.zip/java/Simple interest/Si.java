import java.util.*;
 
public class Si{
void simpleInterest(int principle,int rate,int time){
 double a=(principle * rate * time)/100;
 System.out.println("Simple Interest is: "+a);
}

public static void main(String[] args){

Scanner sc=new Scanner(System.in);

System.out.println("Enter the Principle:");
int p=sc.nextInt();

System.out.println("Enter the Time:");
int t=sc.nextInt();


System.out.println("Enter the Rate of Interest:");
int r=sc.nextInt();

Si obj=new Si();
obj.simpleInterest(p,r,t);


}