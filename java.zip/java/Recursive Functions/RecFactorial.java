class RecFactorial{

 void revno(int n){
   if(n==1) System.out.println("1");
   else{
      System.out.print(n);
      revno(n-1);
    }
 }

 void factorial(int n){
  int fact=n;
  while(n>1){
    n--;
    fact*=n;
   
  }
  System.out.println(fact+" ");
 }


 int recfactorial(int n){
  if(n<=1) 
    return 1;
  return n*recfactorial(n-1); 
 }



 void fib(int f,int s,int c){
 if(c==0) return;
  s+=f;
  f=s-f;
  System.out.println(f);
  fib(f,s,c-1);
  
 }

}