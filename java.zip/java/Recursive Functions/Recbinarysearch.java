import java.util.Arrays;

class Recbinarysearch{
 int bsearch(int[] arr,int start,int end,int key){
  
  if(start<=end){
   int mid=(start+end)/2;
   if(arr[mid]==key){
      System.out.println("Found at Position "+mid); 
      return mid;
   }
   else if(arr[mid]<key){
      start=mid+1;}
   else {
     end=mid-1;}
   return bsearch(arr,start,end,key);
  }
 return -1;
 }

public static void main(String[] args){
int[] arr={2,80,68,563,5789,345,678,89,346};

System.out.print("Array before Sorted: ");
for(int i=0;i<arr.length;i++) System.out.print(arr[i]+" ");
Arrays.sort(arr);

System.out.println(" ");
System.out.print("Array after Sorted: ");

for(int i=0;i<arr.length;i++) System.out.print(arr[i]+" ");
System.out.print("Array after Sorted: ");

int st=0;
int ed=arr.length-1;
int key=5789;

Recbinarysearch r=new Recbinarysearch();
r.bsearch(arr,st,ed,key);

}
}		