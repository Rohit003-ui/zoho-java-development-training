class Gcd{

 int find(int n1,int n2,int small){
  if(small>1){
    if((n1%small==0) && (n2%small==0)){
     System.out.println("GCD is "+small);
     return small;
    }
    else{
      return find(n1,n2,small-1);
    }
  }
  return -1;
 }

public static void main(String[] args){
Gcd g=new Gcd();
int n1=120;
int n2=36;
int small= n1<n2 ? n1:n2;
int gcd=g.find(n1,n2,small);
}
}