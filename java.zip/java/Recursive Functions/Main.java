import java.util.Scanner;
class Main{
public static void main(String[] args){

RecFactorial r =new RecFactorial();

Scanner sc=new Scanner(System.in);

/*
System.out.println("Enter the Number");
int n=sc.nextInt();
System.out.println("Reverse Numbers using the Recursion");
r.revno(n);

System.out.println(" ");
System.out.println("Enter the Number for Factorial");
int no=sc.nextInt();
System.out.print("Factorial of "+no+" is ");
r.factorial(no);

System.out.println(" ");
System.out.println("Factorial using Recursion");
int c=r.recfactorial(no);
System.out.println(c);

*/


int f=0,s=1,c=5;;
r.fib(f,s,c);

}
}