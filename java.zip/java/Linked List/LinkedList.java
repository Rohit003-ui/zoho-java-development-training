class LinkedList{

 Node head=null;

  void insertBeg(int data){
    Node newnode=new Node(data);
   
   newnode.next=head;
   head=newnode;
  }

 
  void insertMid(int data){
   int len=0;
   if(head==null) System.out.println("List is Empty");

   Node temp=head;
   while(temp!=null){
    len++;
    temp=temp.next;
   }
   temp=head;
   for(int i=0;i<(len/2)-1;i++){
    temp=temp.next;
   }
   Node newnode=new Node(data);
   newnode.next=temp.next;
   temp.next=newnode; 

  }


  void insertLast(int data){
   if(head==null) insertBeg(data);

     Node newnode=new Node(data);
     Node temp=head;
     while(temp.next!=null){
       temp=temp.next;
     }
     
     temp.next=newnode;
  }
  
 
  void delBeg(){

   if(head==null) System.out.println("List is Empty");
  
   head=head.next;
  }

 
 void delMid(){

  int len=0;
  if(head==null) System.out.println("List is Empty");
 

   Node temp=head;
   while(temp!=null){
    len++;
    temp=temp.next;
   }
   temp=head;
   for(int i=0;i<(len/2)-1;i++){
    temp=temp.next;
   }
  temp.next=temp.next.next;
 }


 void delLast(){
  if(head==null) System.out.println("List is Empty");

  if(head.next==null) head=null;
  
  Node temp=head;
  while(temp.next.next!=null){
     temp=temp.next;
  }
  temp.next=null;
 }

 void replace(int index,int value){
 if(head==null) System.out.println("List is Empty");
   
   Node temp=head;
   for(int i=0;i<=index;i++){
     temp=temp.next;
   }
  temp.data=value;
 }


  void search(int data){
  if(head==null) System.out.println("List is Empty");

   Node temp=head;
   while(temp!=null){
    if(temp.data==data) System.out.println("Found");
    temp=temp.next;
   }
   
  }

  void display(){
   Node temp=head;
   while(temp!=null){
     System.out.print(temp.data+"->");
     temp=temp.next;
   }
   System.out.println("null");
   System.out.println(" ");
  }

}