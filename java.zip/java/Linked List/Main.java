

class Main{
public static void main(String[] args){

LinkedList l=new LinkedList();

l.insertBeg(1);
l.insertBeg(2);
l.insertBeg(5);
System.out.print("After Inserting Element at First ");
l.display();
System.out.println(" ");


l.insertMid(4);
l.insertMid(3);
System.out.print("After Inserting Element at Middle ");
l.display();
System.out.println(" ");

l.insertLast(6);
l.insertLast(7);
l.insertLast(8);
System.out.print("After Inserting Element at End ");
l.display();
System.out.println(" ");



l.delBeg();
System.out.print("After Deleting Element at First ");
l.display();
System.out.println(" ");


l.delMid();
System.out.print("After Deleting Element at Middle ");
l.display();
System.out.println(" ");

l.delLast();
System.out.print("After Deleting Element at End ");
l.display();
System.out.println(" ");




System.out.println("Searching Element 6 ");
l.display();
l.search(7);
System.out.println(" ");



l.replace(2,5);
System.out.print("After Replacing Element ");
l.display();
System.out.println(" ");



}

}