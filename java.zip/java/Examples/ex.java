class ex{

 void rotation(int[] arr,int k){
  int n=arr.length;
  int[] res=new int[n];
    for(int i=0;i<n;i++){
      res[(i+k)%n]=arr[i];
    }
    for(int i=0;i<n;i++){
       System.out.print(res[i]+" ");
    }
     System.out.println(" ");
 }



   void find(int[] arr){
     System.out.println(" ");
     int n=arr.length;
     int k=9;
     for(int i=0;i<n;i++){
         for(int j=i+1;j<n;j++){
            if((arr[i]+arr[j])==k) System.out.println(arr[i]+" + "+arr[j]+" = "+k);
         }
      }
      System.out.println(" ");
   }


   void nonrepeating(){
   String str = "example";
     for(int i=0;i<str.length();i++) {
       int count = 0;
       for(int j=0;j<str.length();j++) {
          if(str.charAt(i)==str.charAt(j)) count++;
       }
      if(count==1) System.out.print(str.charAt(i) + " ");
       }
   }

  
  void strcom(){
   System.out.println(" ");
   System.out.println(" ");
   String s="aabbbccc";
   int count=1;
    for(int i=0;i<s.length();i++){
      if(i<s.length()-1 && s.charAt(i)==s.charAt(i+1)) count++;
      else{
       System.out.print("["+s.charAt(i)+","+count+"]");
       count=1;
      }
    }
  }

}