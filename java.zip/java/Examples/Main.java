import java.util.Scanner;
class Main{
public static void main(String[] args) {
	
int[] arr={1,2,3,4,5};
Scanner sc=new Scanner(System.in);

System.out.print("Enter the Value of K: ");
int k=sc.nextInt();
ex m=new ex();

  m.rotation(arr,k);

  m.find(arr);

  m.nonrepeating();

  m.strcom();
}
}