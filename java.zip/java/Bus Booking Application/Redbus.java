import java.util.*;

class BusOwner{
 int BusName;
 
     void Display(){
       System.out.println(" ");
       System.out.println("1. Chennai to Salem");
       System.out.println("2. Chennai to Trichy");
       System.out.println("3. Chennai to Madurai");
     }
}



class BusDetails{
  void BusDetails(int n){
     if(n==1){
	System.out.println(" ");
        System.out.println("You have Selected Chennai to Salem Bus");

        System.out.println("Bus Name : Krish");
        System.out.println("Total Seats Available : 30");
        System.out.println("Price of a Ticket : 250");
     }

     else if(n==2){
	System.out.println(" ");
        System.out.println("You have Selected Chennai to Trichy Bus");

        System.out.println("Bus Name : Rpm");
        System.out.println("Total Seats Available : 30");
        System.out.println("Price of a Ticket : 150");
     }
     else if(n==3){
	System.out.println(" ");
	System.out.println("You have Selected Chennai to Madurai Bus");

        System.out.println("Bus Name : Vinayaga");
        System.out.println("Total Seats Available : 30");
        System.out.println("Price of a Ticket : 500");
     }
     else{
          System.out.println("Passenger");
     }
  }
}



class Redbus{
public static void main(String[] args) {
 System.out.println(" ");
 System.out.println("1. Bus Owners");
 System.out.println("2. Passenger");
 
 Scanner sc=new Scanner(System.in);
 System.out.println("\nSelect the role: ");
 int ch=sc.nextInt();
 
 if(ch==1){
  BusOwner bo=new BusOwner();
  bo.Display();

 }


 else if(ch==2){
  System.out.println(" ");
  System.out.println("----------The Bus Lists are----------");
  BusOwner bo=new BusOwner();
  bo.Display();

  System.out.println(" ");
  System.out.println("Select Any bus:");
  int no=sc.nextInt();
  
  BusDetails bd=new BusDetails();
  bd.BusDetails(no);

  
    System.out.println("Enter the Name:");
    String name=sc.nextLine();
 
    System.out.println("Enter the Number:");
    String number=sc.nextLine();

    System.out.println("Enter the Email Id:");
    String email=sc.nextLine();

    System.out.println("Enter the total seat you need to book");
    int ticket=sc.nextInt(); 

 }



 else{
 System.out.println("Invalid User");
 }
 
}
}






















/*


 if(ch==1){
  System.out.println("Bus Owner");
  
}


 if(ch==2){
    System.out.println("Passenger");  
     System.out.println("1. Chennai to Salem");
       System.out.println("2. Chennai to Trichy");
       System.out.println("3. Chennai to Madurai");
     int n=sc.nextInt();
     if(n==1){
        System.out.println("You have Selected Chennai to Salem Bus");

        System.out.println("Bus Name : Krish");
        System.out.println("Total Seats Available : 30");
        System.out.println("Price of a Ticket : 250");
      
        System.out.println("Enter the Name:");
        String name=sc.nextLine();
        Systemout.println("Enter the total seat you need to book");
     }
     else if(n==2){
        System.out.println("You have Selected Chennai to Trichy Bus");
        System.out.println("Bus Name : Rpm");
        System.out.println("Total Seats Available : 30");
        System.out.println("Price of a Ticket : 150");
     }
     else if(n==3){
	System.out.println("You have Selected Chennai to Madurai Bus");
        System.out.println("Bus Name : Vinayaga");
        System.out.println("Total Seats Available : 30");
        System.out.println("Price of a Ticket : 500");
     }
     else{
          System.out.println("Passenger");
     }
}


else{
}


*/


