import java.util.*;

class GroceryShop{
String role;

  GroceryShop(String role){
      this.role=role;
  }

  void display(){
     System.out.println("Role : " + role);
  }
}

class Product{
String name;
String brand;
float price;
int quantity;

    Product(String name, String brand, float price, int quantity){
     this.name=name;
     this.brand=brand;
     this.price=price;
     this.quantity=quantity;
    }

    float getTotal(){
     return price*quantity;
    }

    void display(){
     System.out.println("Product: " + name);
     System.out.println("Brand: " + brand);
     System.out.println("Quantity: " + quantity);
     System.out.println("Total: " + getTotal());
    }
}

class Seller{
    float total;

    Seller(float total){
    this.total=total;
    }

    void display(){
    System.out.println("Total Bill Amount : " + total);
     System.out.println("Thank You For Ordering");
    }
}

public class Grocery{
public static void main(String[] args) {

Scanner sc=new Scanner(System.in);

System.out.println("1. Customer");
System.out.println("2. Shop Keeper");
System.out.print("Select Role: ");
int ch = sc.nextInt();

 if (ch==1){
   GroceryShop g=new GroceryShop("Customer");
   g.display();

  Product p1=new Product("Biscuits", "Britannia", 20, 2);
  Product p2=new Product("Flour", "Aashirvaad", 60, 1);

  p1.display();
  p2.display();

 float total=p1.getTotal() + p2.getTotal();
  Seller s=new Seller(total);
  s.display();
}
else if (ch==2) {
   GroceryShop g=new GroceryShop("Shop Keeper");
   g.display();
   System.out.println("Any Help");
}
else {
 System.out.println("Invalid Choice");
}


}
}
